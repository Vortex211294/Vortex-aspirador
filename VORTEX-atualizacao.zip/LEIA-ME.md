# VORTEX ASPIRADOR — atualização de 06/10/2026

Esta atualização parte do `index.html` original de 5.589 linhas, no commit `fa01632`, do repositório `vortex211294/Vortex-aspirador`. Mantém o visual azul/preto, as páginas, os gráficos Seg–Dom e as integrações existentes. Os arquivos estão preparados localmente; não foram publicados no GitHub nem executados no Supabase.

## O que foi corrigido

- Login e cadastro recuperam os botões após falhas de conexão; o login distingue e-mail não confirmado. A senha é limpa após autenticação.
- Equipamentos, PIX, relatórios, financeiro e mensalidades usam filtro explícito da conta do cliente. A Central mantém as consultas gerais. Essa filtragem complementa as regras RLS do banco, cuja autorização ainda precisa ser verificada.
- Históricos são paginados em blocos de 100, evitando totais truncados em 500 ou 1.000 registros. Consultas incompletas mostram falha.
- Trocar o equipamento no PIX atualiza preço, tempo e valor configurado. A criação rejeita minutos fracionários e valores inválidos, e impede cliques duplicados durante a chamada.
- A consulta de um PIX antigo não sobrescreve uma cobrança nova. Copiar o código preserva o status do pagamento. A confirmação do pagamento não envia um comando adicional ao motor pelo navegador.
- A confirmação do PIX e o envio de um comando não são apresentados como prova de acionamento físico. O painel do controlador mostra as datas de envio, recebimento e finalização existentes no banco.
- Configuração do equipamento atualiza os caches após salvar. O acionamento remoto recupera o botão após erro.
- Financeiro exibe registros de pagamentos, mensalidades e repasses. Saldo ou repasses indisponíveis aparecem como `—`, sem inventar saldo zero.
- Relatórios validam o período, consultam todas as páginas, incluem o fim do dia e usam datas de São Paulo. “Minutos comprados” não é apresentado como tempo efetivamente utilizado.
- Dados de texto dos clientes e equipamentos são escapados ao montar HTML; nomes com aspas não quebram o botão de acionamento.
- A tela de recebimento salva e carrega pelo servidor, com uma migração aditiva. Wi-Fi, reinício e firmware permanecem indisponíveis até existir controlador compatível. Preferências de notificações são locais; envio automático ainda não foi implementado.

## Aplicação

1. No GitHub, abra o repositório `Vortex-aspirador`. Em **Add file → Upload files**, envie o `index.html` deste pacote para substituir o arquivo da raiz e confirme o commit na `main`. O histórico anterior continua disponível no GitHub.
2. Aguarde o deploy do GitHub Pages e recarregue o app com **Ctrl + F5**.
3. No SQL Editor do **mesmo projeto Supabase do VORTEX**, execute `supabase/01_recebimento.sql` para ativar o salvamento e a leitura dos dados de recebimento. O script requer `clientes.id` e `clientes.user_id` do tipo UUID. Não modifica as funções financeiras nem as funções de acionamento existentes. O novo cadastro de recebimento é independente do anterior: dados gravados pela função antiga não são migrados automaticamente.
4. Execute `supabase/02_diagnostico.sql` para conferir tabelas, colunas, funções e políticas. Esse diagnóstico apenas lê a estrutura; não lista dados dos clientes nem chaves do controlador.

## Testes realizados

`node --test tests/fluxos.test.cjs`

18 testes com respostas simuladas: sintaxe, IDs e ações HTML, filtro cliente/ADMIN, 1.127 registros, virada do dia no Brasil, escape de texto, troca de equipamento, valores PIX inválidos, clique duplicado, corrida entre cobranças, cópia do PIX, falha do comando remoto, falha do login, saldo indisponível, período de relatório, configurações e telas vazias.

Os testes não acessam o banco de produção, não fazem transferências nem ligam motores. O SQL foi revisado, mas não executado em um servidor PostgreSQL nesta sessão. A tela de login publicada foi aberta; o GitHub neste ambiente está sem autenticação para publicar.

## O que precisa ser validado no projeto real

| Item | Validação necessária |
|---|---|
| Conta ADMIN e conta cliente | Entrar nas duas contas; cliente A não pode ler ou alterar equipamentos, pagamentos ou dados de cliente B, inclusive por chamadas diretas ao banco. Cliente também deve poder acionar os próprios equipamentos. |
| RLS e funções existentes | Verificar autorização no servidor, especialmente `tipo_usuario`, `acionar_equipamento_remoto`, configuração do equipamento, saldos e repasses. O frontend não pode garantir isso sozinho. |
| PIX / PagBank | Conferir `criar-pix-vortex` e `pagbank-webhook`, o ambiente sandbox/produção, validação do preço no servidor, referência individual, assinatura/origem do webhook, consulta da transação e processamento idempotente de confirmações repetidas. A palavra “PAID” recebida isoladamente não basta para autorizar equipamento. |
| Mensalidade | Confirmar o agendamento, evitar cobranças duplicadas e verificar a periodicidade desejada de **30 dias**. A função existente citada no histórico, `gerar_mensalidades_do_mes`, pode usar mês calendário. Essa revisão não altera a cobrança sem verificar sua implementação. Valor: **R$50**. Comissão: **2,99%**. |
| Repasses | `registrar_repasse_cliente` registra o repasse no banco. Confirmar se a transferência bancária ocorre separadamente; não apresentar um registro como comprovante de transferência automática. Testar concorrência e saldo no servidor. |
| Tela pública de pagamento | O gerador atual fica no painel autenticado. A compra pública por código do equipamento e a confirmação pública exigem contrato próprio, sem expor dados de outros clientes. Não foram criadas nesta revisão. |
| Controlador físico | Testar heartbeat, recebimento único do comando, temporizador, desligamento automático, reconexão, falha de energia e confirmação de término. Hardware/firmware ainda ausentes; não há validação dos dois motores nesta sessão. |
| Notificações | Definir e ativar o serviço de envio automático, com as preferências por conta. As opções existentes só ficam salvas neste navegador. |

Para concluir essas integrações, é necessário acesso autenticado ao projeto Supabase ou os códigos atuais das Edge Functions e os resultados do diagnóstico. Não envie senhas, tokens PagBank, chaves de serviço ou chaves do controlador na conversa.
